/*********************************************************************************
 *                                 _             _
 *                                | |_  ___ _ __(_)__ _
 *                                | ' \/ -_) '_ \ / _` |
 *                                |_||_\___| .__/_\__,_|
 *                                         |_|
 *
 *********************************************************************************
 *
 * Company: hepia
 * Author: <author>
 *
 * Project Name: <prj_name>
 * Target Device: <board_name> <part_name>
 * Tool version: <tool_version>
 * Description: <prj_name> software driver header file
 *
 * Last update: <update_time>
 *
 ********************************************************************************/

#ifndef <upper_prj_name>_H
#define <upper_prj_name>_H

#endif  // <upper_prj_name>_H
